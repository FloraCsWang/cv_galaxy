img_size = (69, 69)
crop_size = (45, 45)

data_loader = dataLoader( data_indices = data_indices, batch_size=batch_size, shuffle=True)

for batch_idx, (data, target) in enumerate(data_loader):
    # data: torch.tensor, size([batch_size, 3*16, crop_size[0], crop_size[1]]), the second dimension stands for 3 RGB channel times 16 viewpoints.
    # target torch.tensor, size([batch_size, 37])
